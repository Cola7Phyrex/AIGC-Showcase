# AINEWS Daily Runbook

Use this runbook to produce one daily report.

## Inputs

Required:

- Current date and time.
- `docs/AINEWS_RULES.md`
- `docs/OUTPUT_SCHEMA.md`
- `docs/SOURCE_SEEDS.md`

Optional:

- `inbox/links-YYYY-MM-DD.md`
- User-provided links in the current chat.

## Output Paths

For date `YYYY-MM-DD`, create:

```text
reports/YYYY-MM-DD/
  ai-daily-YYYY-MM-DD.md
  items-YYYY-MM-DD.json
```

## Step 1: Establish Window

Use `Asia/Shanghai`.

Default:

```text
collection_window_start = run_time - 24 hours
collection_window_end = run_time
```

Write the exact window in both Markdown and JSON metadata.

## Step 2: Build Candidate Pool

Search each category separately.

### Models

Use official and technical sources first:

- OpenAI, Anthropic, Google DeepMind, Google AI, Meta AI, Mistral, xAI, Microsoft, NVIDIA, Apple ML.
- Qwen, DeepSeek, Moonshot/Kimi, Zhipu/GLM, Baidu ERNIE, Tencent Hunyuan, ByteDance/Doubao, MiniMax, SenseTime, iFLYTEK, ModelScope.
- Hugging Face, arXiv, Papers with Code, Artificial Analysis, Arena leaderboard.

Queries should include:

- `site:official-domain AI model July YYYY`
- `site:huggingface.co model release YYYY-MM-DD`
- `site:arxiv.org large language model multimodal agent YYYY-MM-DD`
- Chinese queries for domestic model releases.

### Products

Use launch and developer-product sources:

- Product Hunt.
- Hacker News.
- GitHub Trending / new releases.
- Tool websites and changelogs.
- App stores and extension marketplaces.
- Developer blogs.

Queries should include:

- `AI product launched today`
- `LLM agent product update`
- `Claude Code Codex Cursor new tool`
- `AI video editor launch`
- `MCP AI tool launch`

### Personal Works / Workflows

Use creative and community sources:

- GitHub.
- Hacker News.
- Product Hunt.
- YouTube.
- Bilibili.
- TikTok.
- Douyin.
- X.
- Xiaohongshu.
- Reddit.
- Creator blogs.

Queries should include:

- `AI generated video workflow tutorial`
- `Claude Code game`
- `vibe coding game`
- `ComfyUI workflow`
- `AI music video tutorial`
- `AI H5 app game`
- Chinese equivalents: `AI 工作流 复刻`, `Claude Code 游戏`, `AI 生成 视频 教程`, `AI 小程序`, `AI 个人作品`.

If short-video platforms are unstable, prioritize user-provided `inbox` links and record the limitation.

## Step 3: Verify and Deduplicate

For each candidate:

1. Find the highest-tier source.
2. Check publication/update time.
3. Merge duplicates under one item.
4. Remove outside-window items unless used as `workflow_observation` or `watchlist`.
5. Reject low-confidence rumor items.

Keep an `excluded` list for notable rejected items.

## Step 4: Score and Classify

For every accepted item, assign:

- `category`
- `event_type`
- `source_tier`
- `confidence`
- `novelty`
- `impact`
- `availability`
- `mainland_access`
- `global_access`
- `tags`
- `dedupe_key`

For creative workflows, also assign:

- `work_type`
- `ai_share`
- `models_used`
- `tools_used`
- `has_demo`
- `has_tutorial`
- `has_prompt`
- `has_code`
- `replicability`
- `wow_factor`
- `idea_transferability`
- `source_platform`

## Step 5: Verify and Record Full URLs

Every accepted item must have at least one direct, complete source URL.

- In Markdown, display the full URL literally, for example: `完整网址：https://example.com/path`.
- Do not hide the URL behind link text such as “官网”, “来源”, or “点击查看”.
- Prefer the exact release, documentation, repository, store, demo, video, or author page over a homepage or search-results URL.
- In JSON, `source_url` must be an absolute `http://` or `https://` URL. Put other verified evidence URLs in `additional_source_urls` when useful.
- Do not capture screenshots, thumbnails, or video keyframes. Do not create an `assets/` directory. Do not add media objects to new JSON output.

## Step 6: Write Human Report

Create:

`reports/YYYY-MM-DD/ai-daily-YYYY-MM-DD.md`

Required sections:

```text
# AI Daily - YYYY-MM-DD

采集窗口
版本说明

## 今日最值得关注
## 模型动态
## AI / LLM 产品
## AI 个人作品 / 可复刻工作流
## 观察但未收录
## 本次试跑/运行结论
```

For each item, include:

- Title.
- Source and date.
- Core information.
- Why it matters.
- Availability.
- Mainland/global access if relevant.
- Confidence/source tier.
- Full source URL shown literally, not only as hidden Markdown link text.
- Additional full evidence URLs when they materially support the item.

For workflows, also include:

- Work type.
- Result.
- AI share.
- Models used.
- Tools used.
- Replication difficulty.
- Transferable ideas.

## Step 7: Write Machine Review JSON

Create:

`reports/YYYY-MM-DD/items-YYYY-MM-DD.json`

Follow `docs/OUTPUT_SCHEMA.md`.

Ensure the JSON parses with:

```bash
jq '.items | length' reports/YYYY-MM-DD/items-YYYY-MM-DD.json
```

## Step 8: Final Verification

Run:

```bash
find reports/YYYY-MM-DD -maxdepth 2 -type f -print
jq '.items | length' reports/YYYY-MM-DD/items-YYYY-MM-DD.json
jq -e 'all(.items[]; (.source_url | type == "string" and test("^https?://")))' reports/YYYY-MM-DD/items-YYYY-MM-DD.json
```

Check:

- Markdown exists.
- JSON exists and parses.
- Every accepted item has a complete absolute `source_url`.
- Every Markdown item visibly prints its complete primary URL.
- New output contains no screenshot/media artifacts or media objects.
- The item count is reasonable.

## Step 9: Final Reply

Report:

- Markdown path.
- JSON path.
- Number of accepted items.
- Full-URL validation result.
- Major limitations.
- Any failed or unstable links that need user help.
