# AINEWS Source Seeds

Use these sources as starting points. Do not treat this list as exhaustive.

## Model Sources

### International Official

- OpenAI News: https://openai.com/news/
- OpenAI Developers Blog: https://developers.openai.com/blog/
- Anthropic News: https://www.anthropic.com/news
- Anthropic Research: https://www.anthropic.com/research
- Google DeepMind Blog: https://deepmind.google/blog/
- Google AI Blog: https://ai.googleblog.com/
- Meta AI Blog: https://ai.meta.com/blog/
- Mistral News: https://mistral.ai/news/
- xAI News: https://x.ai/news
- Microsoft AI Blog: https://blogs.microsoft.com/ai/
- NVIDIA Blog AI: https://blogs.nvidia.com/blog/category/deep-learning/
- Apple Machine Learning Research: https://machinelearning.apple.com/

### China / Chinese-Language Official

- Qwen Blog: https://qwenlm.github.io/blog/
- DeepSeek Updates: https://api-docs.deepseek.com/updates
- Kimi / Moonshot: https://kimi.moonshot.cn/
- Zhipu AI: https://www.zhipuai.cn/
- Baidu Wenxin: https://yiyan.baidu.com/
- Tencent Hunyuan: https://hunyuan.tencent.com/
- ModelScope: https://www.modelscope.cn/
- Alibaba Cloud Model Studio: https://bailian.console.aliyun.com/

### Technical / Benchmark

- Hugging Face Papers: https://huggingface.co/papers
- Hugging Face Models: https://huggingface.co/models
- arXiv cs.AI new: https://arxiv.org/list/cs.AI/new
- arXiv cs.CL new: https://arxiv.org/list/cs.CL/new
- arXiv cs.CV new: https://arxiv.org/list/cs.CV/new
- Papers with Code: https://paperswithcode.com/
- Artificial Analysis: https://artificialanalysis.ai/
- Arena Leaderboard: https://arena.ai/leaderboard

## Product Sources

- Product Hunt: https://www.producthunt.com/
- Hacker News: https://news.ycombinator.com/news
- GitHub Trending: https://github.com/trending
- GitHub Releases search: https://github.com/search
- Chrome Web Store: https://chromewebstore.google.com/
- VS Code Marketplace: https://marketplace.visualstudio.com/vscode
- Apple App Store web: https://www.apple.com/app-store/
- Microsoft Store: https://apps.microsoft.com/
- Futurepedia: https://www.futurepedia.io/
- There is an AI for That: https://theresanaiforthat.com/

## AI Personal Works / Workflow Sources

### International

- Hacker News: https://news.ycombinator.com/news
- GitHub Trending: https://github.com/trending
- Product Hunt: https://www.producthunt.com/
- YouTube: https://www.youtube.com/
- TikTok: https://www.tiktok.com/
- Reddit LocalLLaMA: https://www.reddit.com/r/LocalLLaMA/
- Reddit StableDiffusion: https://www.reddit.com/r/StableDiffusion/
- Reddit ClaudeAI: https://www.reddit.com/r/ClaudeAI/
- Hugging Face Spaces: https://huggingface.co/spaces

### China / Chinese-Language

- Bilibili: https://www.bilibili.com/
- Douyin: https://www.douyin.com/
- Xiaohongshu: https://www.xiaohongshu.com/
- Zhihu: https://www.zhihu.com/
- Jike: https://web.okjike.com/
- Jiqizhixin: https://www.jiqizhixin.com/
- QbitAI: https://www.qbitai.com/
- 36Kr: https://36kr.com/
- Zhidongxi: https://zhidx.com/
- AIbase: https://www.aibase.com/

## Suggested Query Patterns

### English

- `AI model release today`
- `site:openai.com/news model`
- `site:anthropic.com/research Claude`
- `site:deepmind.google/blog Gemini`
- `site:huggingface.co model release`
- `site:arxiv.org multimodal agent`
- `AI product launched today agent`
- `Claude Code game`
- `vibe coding game`
- `AI generated video workflow tutorial`
- `ComfyUI workflow tutorial`
- `AI music video generated tutorial`
- `MCP AI tool launch`

### Chinese

- `AI 模型 发布 今天`
- `大模型 发布 7月`
- `多模态 模型 开源`
- `具身智能 模型 开源`
- `AI 产品 发布 今天`
- `AI 工作流 复刻`
- `Claude Code 游戏`
- `AI 生成 视频 教程`
- `AI 音乐 工作流`
- `AI 小程序 作品`
- `AI H5 游戏`

## Notes

- Prefer Bing or broad web search when possible.
- Do not rely on Google-only paths.
- For short-video platforms, prefer user-supplied canonical video/work URLs or exported full URLs; use an author profile only when the exact work URL is unavailable, and record that limitation.
- For China sources, official WeChat posts may be difficult to scrape. Use credible reposts only when the original account and date are visible.
