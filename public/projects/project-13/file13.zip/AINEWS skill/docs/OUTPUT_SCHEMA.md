# AINEWS Output Schema

This document defines the expected structure for the machine-readable daily JSON.

## File Path

`reports/YYYY-MM-DD/items-YYYY-MM-DD.json`

## Root Object

```json
{
  "metadata": {},
  "items": [],
  "excluded": []
}
```

## Metadata

Required fields:

```json
{
  "report_date": "YYYY-MM-DD",
  "timezone": "Asia/Shanghai",
  "collection_window_start": "YYYY-MM-DDTHH:mm:ss+08:00",
  "collection_window_end": "YYYY-MM-DDTHH:mm:ss+08:00",
  "version": "standard_trial",
  "notes": []
}
```

## Common Item Fields

Every item must include:

```json
{
  "id": "YYYY-MM-DD-category-slug",
  "category": "model | product | creative_workflow",
  "title": "",
  "entity": "",
  "event_type": "",
  "source_url": "",
  "source_tier": "S | A | B | C | D",
  "published_at": "",
  "confidence": 0.0,
  "novelty": 1,
  "impact": 1,
  "availability": "",
  "mainland_access": "yes | no | partial | unknown",
  "global_access": "yes | no | partial | unknown",
  "summary": "",
  "why_it_matters": "",
  "tags": [],
  "additional_source_urls": [],
  "dedupe_key": ""
}
```

URL requirements:

- `source_url` is required and must be a complete absolute URL beginning with `https://` or `http://`.
- `additional_source_urls` is optional and contains only complete absolute URLs for other verified evidence.
- New reports do not include `media`. Older reports may retain legacy `media` fields for backward compatibility.

Recommended `event_type` values:

- `release`
- `update`
- `research`
- `paper`
- `launch`
- `demo`
- `tutorial`
- `benchmark`
- `pricing_change`
- `access_change`
- `trending`
- `review`
- `workflow_observation`
- `watchlist`

## Creative Workflow Extra Fields

For `category = creative_workflow`, add:

```json
{
  "work_type": "image | video | music | audio | h5 | app | mini_program | game | text_game | rule_system | document_generation | hardware_interaction | agent_workflow | other",
  "ai_share": "low | medium | medium_high | high | near_total | unknown",
  "models_used": [],
  "tools_used": [],
  "has_demo": true,
  "has_tutorial": false,
  "has_prompt": false,
  "has_code": false,
  "replicability": 1,
  "wow_factor": 1,
  "idea_transferability": 1,
  "source_platform": "",
  "notes": ""
}
```

## Excluded Object

Use this for notable candidates that were rejected.

```json
{
  "title": "",
  "reason": "",
  "source_url": ""
}
```

## Validation Checklist

Before final reply:

- JSON parses with `jq`.
- `items` is an array.
- Every item has a complete absolute `source_url` beginning with `http://` or `https://`.
- Every value in `additional_source_urls`, when present, is also a complete absolute URL.
- New reports contain no `media` field and no screenshot/media artifacts.
- No item in the main report depends only on a D-tier source.
- Out-of-window items are labeled as `workflow_observation` or excluded.
