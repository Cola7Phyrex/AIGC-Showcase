# AINEWS Rules

This document defines the editorial rules for the daily AI intelligence report.

## Goal

Produce a daily, evidence-backed AI report that helps the reader understand:

1. Important AI model developments.
2. Useful AI / LLM-driven products and product updates.
3. AI personal works and replicable creative workflows.

The report must optimize for credibility, usefulness, and repeatability. Do not maximize item count.

## Time Window

Default window: the latest 24 hours from the run time, using `Asia/Shanghai`.

If a source is outside the 24-hour window but is actively trending within the window, it may be added only as `workflow_observation` or `watchlist`, not as today's primary news.

Always write the exact collection window in the report.

## Source Tiers

Use these tiers in both judgment and machine-readable output.

### S: First-party official

Official blogs, docs, release notes, model cards, pricing pages, API docs, GitHub releases, Hugging Face model pages, ModelScope pages, arXiv papers, app store listings, Chrome / VS Code marketplace pages.

Use S sources as the strongest factual basis.

### A: Traceable primary-adjacent

Official social posts, official forums, official Discord/forum announcements, conference pages, benchmark/leaderboard pages, GitHub repositories without formal releases, product changelogs.

Use A sources when a formal official article is not available.

### B: Credible secondary

Reuters, AP, The Verge, TechCrunch, InfoQ, SCMP, machine-learning outlets, QbitAI, 36Kr, Zhidongxi, Jiqizhixin, AIbase and similar specialist media.

Use B sources for discovery and context. For hard facts such as model specs, pricing, access, and open-source claims, try to confirm with S/A sources.

### C: Discovery and community

Product Hunt, Hacker News, GitHub Trending, Reddit, X, YouTube, Bilibili, TikTok, Douyin, Xiaohongshu, Zhihu, Jike.

Use C sources to find products and creative works. Upgrade confidence only when the original project, author page, repo, demo, tutorial, or app listing is found.

### D: Rumor

Anonymous leaks, screenshots without links, unverified reposts, vague short videos, unattributed claims.

Do not include D sources in the main report. Mention only in "Observed but not included" if useful.

## Section Standards

### AI Models

Include if at least one is true:

- New model, model family, model weight, API, benchmark, paper, or model-card update within the time window.
- Major availability or pricing change within the time window.
- Strong official research that changes how models are evaluated, interpreted, or deployed.

Required checks:

- Who released it.
- Open, open-weight, API-only, closed, or research-only.
- Modality: text, vision, audio, video, robotics, embedding, coding, multimodal, etc.
- Availability: API, web app, GitHub, Hugging Face, ModelScope, local, waitlist, enterprise-only.
- Mainland China usability if discoverable.
- At least one S/A source, or B source plus traceable primary link.

Avoid:

- Pure benchmark reposts without context.
- Rumors of future model names.
- Funding/personnel news unless it changes model/product access.

### AI / LLM Products

Include if at least one is true:

- New product launch within the time window.
- Major update, pricing/access change, platform expansion, or workflow-relevant feature.
- Tool is newly trending and directly useful for AI builders, creators, or daily workflows.

Required checks:

- What problem it solves.
- Where it runs: Web, iOS, Android, Mac, Windows, Linux, browser extension, VS Code, CLI, API, MCP, plugin, hardware.
- Access condition: free, paid, waitlist, invite, enterprise, region/account requirements.
- Whether it is usable now.
- Whether it matters to the reader's AI workflow.

Prefer products with official websites, docs, GitHub repos, product pages, app listings, or clear demos.

### AI Personal Works / Replicable Workflows

This section covers individual AI creations and AI-assisted workflows, including:

- AI images.
- AI videos.
- AI music/audio.
- Vibe coding projects: H5, websites, apps, mini programs, games.
- Interactive fiction, text games, rule systems.
- Personal automations.
- Hardware + AI interaction demos.
- ComfyUI / Blender / Unity / Three.js / CapCut / workflow-chain creations.

Judgment priorities:

1. Wow factor: is the result visually, interactively, or conceptually impressive?
2. AI share: how much of the result is enabled by AI rather than conventional manual production?
3. Replicability: can the reader reproduce it with available tools, prompts, code, or workflow files?
4. Transferability: can the idea be adapted into the reader's own projects?

Required checks:

- Work type.
- Final result: demo, screenshot, video, repo, playable link, downloadable artifact.
- AI models used, if discoverable.
- Non-AI tools used.
- Human contribution: concept, prompt, editing, code integration, art direction, deployment.
- Tutorial/prompt/code/workflow availability.
- Replication difficulty: low, medium, high.

Source rules are looser here, but do not invent missing model/tool details. If the source does not disclose the model, write `unknown`.

## Scoring

Use 1-5 integer scores unless JSON schema requires another format.

### Novelty

1: common repost or minor update.  
3: useful new capability or notable launch.  
5: genuinely new direction, major release, or surprising capability.

### Impact

1: niche curiosity.  
3: useful to a meaningful audience.  
5: likely to affect many AI builders, creators, or model users.

### Confidence

Use 0.0-1.0.

- 0.95+: official first-party source with clear details.
- 0.80-0.94: repo/paper/official-adjacent or credible source with traceable evidence.
- 0.65-0.79: credible secondary or community source, useful but incomplete.
- Below 0.65: normally exclude from main report.

### Creative Workflow Scores

`wow_factor`, `replicability`, and `idea_transferability` use 1-5.

For `replicability`, 5 means easy to reproduce with linked instructions and accessible tools; 1 means inspiration only.

## Mainland / International Access

Use one of:

- `yes`
- `no`
- `partial`
- `unknown`

Consider:

- Network accessibility.
- Region restrictions.
- Phone/payment/account requirements.
- App store availability.
- API key availability.
- Whether a local/offline path exists.

Do not overstate mainland access unless actually verified or clearly implied.

## URL Rules

Every main item and every item in “Observed but not included” must show a complete, directly usable URL.

- In the human-readable Markdown, print the literal absolute URL beginning with `https://` or `http://`. A descriptive Markdown link alone is not sufficient because it hides the address.
- In JSON, `source_url` is required and must be an absolute URL. Use `additional_source_urls` for other verified evidence when needed.
- Prefer the exact article, release note, model card, repository, product listing, demo, video, or creator post. Do not substitute a search-result URL, URL shortener, or generic homepage when a direct page exists.
- If a social platform exposes only an unstable share URL, preserve the complete URL and note the limitation. If no stable or complete URL can be produced, do not include the candidate in the main report.
- Do not take or save screenshots, thumbnails, covers, or video keyframes. Do not create an `assets/` directory and do not include media objects in new JSON reports.

## Exclusions

Exclude or put into "Observed but not included":

- Outside-window items unless actively trending and labeled correctly.
- Unverified future model rumors.
- Pure marketing claims without access details.
- Duplicate reposts of the same launch.
- Social posts with no source trail.
- Creative works with no visible result.

## Tone

Use direct, practical Chinese. Explain why each item matters and whether the reader can use or replicate it.

Avoid hype words unless describing a creative-work wow factor. Even then, explain the concrete reason.
