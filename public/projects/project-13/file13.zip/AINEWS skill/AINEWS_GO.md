# AINEWS GO

复制下面这段给 Codex，用于每天手动启动标准版 AI 日报。

```text
请执行今日标准版 AI 日报任务。

先阅读并遵守以下文档：
- ~/docs/DAILY_RUNBOOK.md
- ~/docs/AINEWS_RULES.md
- ~/docs/OUTPUT_SCHEMA.md
- ~/docs/SOURCE_SEEDS.md

任务要求：
1. 采集最近 24 小时内的 AI 信息，时区使用 Asia/Shanghai，并在报告中写清楚精确时间窗口。
2. 覆盖三类信息：
   - AI 模型动态：开源、闭源、商业模型、小模型、多模态模型、具身/机器人模型、embedding、coding、音视频模型等。
   - AI / LLM 产品：新发布、重大更新、使用攻略、可用平台、价格/权限/地区条件。
   - AI 个人作品 / 可复刻工作流：AI 图片、视频、音乐音频、vibe coding、H5、app、小程序、游戏、文字游戏、规则系统、硬件交互等。重点判断成果是否炫酷、AI 占比、使用模型/工具、是否可复刻、能否迁移到我的想法。
3. 如果存在今天日期的 links-YYYY-MM-DD.md，请优先纳入其中的链接，尤其是抖音、TikTok、B站、小红书、YouTube 等 AI 个人作品链接。
4. 严格执行来源分级和筛选。模型动态优先官方/论文/GitHub/Hugging Face/ModelScope；产品优先官网、Product Hunt、HN、GitHub、商店页；个人作品可适当放宽，但不能编造模型、工具或教程细节。
5. 每一条信息都必须包含可直接复制和访问的完整网址。在 Markdown 中必须原样显示 `https://...`，不能只写“官网”“来源”“点击查看”等隐藏网址的链接文字；JSON 的 `source_url` 必须是完整的绝对网址。
6. 不需要截图、封面或视频关键帧，不创建 `assets/` 目录，也不运行任何截图工具。JSON 中不再输出媒体对象。
7. 输出双版本：
   - reports/YYYY-MM-DD/ai-daily-YYYY-MM-DD.md
   - reports/YYYY-MM-DD/items-YYYY-MM-DD.json
8. JSON 必须可以被 jq 解析，并校验每个主条目的 `source_url` 都以 `http://` 或 `https://` 开头。完成后请在最终回复中告诉我：
   - 人读版路径
   - 机器审阅版路径
   - 收录条数
   - 完整网址校验结果
   - 本次失败项或需要我人工补充的链接

请尽量一次性跑完。如果出现无法绕过的问题，例如关键网站需要登录、短视频平台无法访问或网络无法搜索，请及时停止并说明需要我提供什么帮助。
```
